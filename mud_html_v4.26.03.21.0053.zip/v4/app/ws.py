import asyncio
import time
from fastapi import WebSocket, WebSocketDisconnect
from .mud.state import log_state_read
from .sessions import SessionManager
from .logger import get_logger
from .config import (
    SESSION_TIMEOUT_MINUTES,
    WS_RATE_LIMIT_MAX_MESSAGES,
    WS_RATE_LIMIT_WINDOW_SECONDS,
    WS_CLOSE_CODES,
    HISTORY_REQUEST_DEFAULT_LINES,
    HISTORY_REQUEST_MIN_LINES,
    HISTORY_MAX_LINES,
)
from .ws_messages import make_message, parse_message
from .ws_handlers import (
    handle_connect,
    handle_disconnect,
    handle_login,
    handle_command,
    handle_raw_command,
)

# Gerenciador global de sessões
session_manager = SessionManager(session_timeout_minutes=SESSION_TIMEOUT_MINUTES)
logger = get_logger("ws")


async def websocket_endpoint(ws: WebSocket):
    """WebSocket endpoint - manages client connections"""
    await ws.accept()
    
    session = None
    public_id = None
    
    try:
        # Aguarda mensagem inicial com publicId
        msg = await ws.receive_text()

        try:
            parsed = parse_message(msg)
            if not parsed:
                raise ValueError("invalid_json")

            msg_type = parsed.get("type")
            payload = parsed.get("payload") or {}
            
            if msg_type == "init":
                # Cliente enviou publicId (e opcionalmente owner)
                public_id = payload.get("publicId")
                ownership_token = payload.get("owner")
                
                if not public_id:
                    logger.error("No publicId provided in init message")
                    await ws.send_json(make_message("error", {"message": "publicId is required"}))
                    return
                
                logger.info(f"Client initialized with publicId: {public_id}")
                
                # Obtém ou cria sessão (com validação de ownership)
                session, status, is_valid = session_manager.get_or_create_session(public_id, ownership_token)
                
                # Se sessão é inválida (ownership errado, desconectada manualmente, ou limite atingido)
                if not is_valid:
                    logger.error(f"Session validation failed: {status}")
                    
                    if status == "invalid_ownership":
                        error_msg = "Session belongs to another client. Generating new session..."
                    elif status == "manual_disconnect":
                        error_msg = "Session was closed. Generating new session..."
                    elif status == "max_sessions":
                        error_msg = "Server at capacity. Try again later."
                    else:
                        error_msg = "Invalid session. Generating new session..."
                    
                    close_code = WS_CLOSE_CODES["max_sessions"] if status == "max_sessions" else WS_CLOSE_CODES["session_invalid"]
                    await ws.send_json(make_message("session_invalid", {
                        "reason": status,
                        "message": error_msg
                    }))
                    await ws.close(code=close_code, reason=status)
                    return
                
                # Sessão válida - adiciona WebSocket
                session.add_websocket(ws)
                
                # Envia o estado atual ao cliente
                log_state_read(session.state, f"send_state_to_client_{public_id}")
                await ws.send_json(make_message("state", {"value": session.state.value}))
                
                # Envia o histórico se existir (apenas as últimas N linhas padrão)
                if session.history:
                    recent_history = session.get_recent_history(num_lines=HISTORY_REQUEST_DEFAULT_LINES)
                    total_lines = len(session.history.split('\n'))
                    returned_lines = len(recent_history.split('\n')) if recent_history else 0
                    await ws.send_json(make_message("history", {
                        "content": recent_history,
                        "is_recent": True,
                        "has_more_history": total_lines > returned_lines,
                        "total_lines": total_lines,
                        "returned_lines": returned_lines
                    }))
                
                # Confirma inicialização com ownership token
                await ws.send_json(make_message("init_ok", {
                    "publicId": public_id,
                    "owner": session.owner_token,
                    "status": status,
                    "hasHistory": bool(session.history)
                }))
            else:
                logger.error(f"Expected 'init' message, got '{msg_type}'")
                await ws.send_json(make_message("error", {"message": "First send 'init' message"}))
                return
        
        except ValueError:
            logger.error("Invalid JSON in initial message")
            await ws.send_json(make_message("error", {"message": "Invalid JSON"}))
            return
        
        # Rate limiting: janela deslizante de timestamps
        message_timestamps = []

        # Loop de mensagens
        while True:
            msg = await ws.receive_text()

            # Rate limiting check
            now = time.monotonic()
            message_timestamps = [t for t in message_timestamps if now - t < WS_RATE_LIMIT_WINDOW_SECONDS]
            message_timestamps.append(now)
            if len(message_timestamps) > WS_RATE_LIMIT_MAX_MESSAGES:
                logger.warning(f"Session {public_id}: Rate limit exceeded ({len(message_timestamps)} msgs in {WS_RATE_LIMIT_WINDOW_SECONDS}s)")
                await ws.send_json(make_message("error", {"message": "Too many messages. Please wait."}))
                continue

            try:
                parsed = parse_message(msg)
                if not parsed:
                    raise ValueError("invalid_json")

                msg_type = parsed.get("type")
                payload = parsed.get("payload") or {}
                
                if msg_type == "connect":
                    await handle_connect(session, ws, public_id, session_manager)
                
                elif msg_type == "disconnect":
                    await handle_disconnect(session, ws, public_id, session_manager)
                
                elif msg_type == "login":
                    await handle_login(session, ws, public_id, payload)
                
                elif msg_type == "command":
                    await handle_command(session, ws, public_id, payload)
                
                elif msg_type == "request_history":
                    # Cliente requisita histórico antigo (lazy loading)
                    try:
                        from_line_index = int(payload.get("from_line_index", 0))
                    except (TypeError, ValueError):
                        from_line_index = 0

                    try:
                        requested_num_lines = int(payload.get("num_lines", HISTORY_REQUEST_DEFAULT_LINES))
                    except (TypeError, ValueError):
                        requested_num_lines = HISTORY_REQUEST_DEFAULT_LINES

                    num_lines = max(HISTORY_REQUEST_MIN_LINES, min(HISTORY_MAX_LINES, requested_num_lines))
                    history_slice = session.get_history_slice(from_line_index, num_lines)
                    await ws.send_json(make_message("history_slice", history_slice))
            
            except ValueError:
                # Mensagem não é JSON, trata como comando direto (backward compatibility)
                await handle_raw_command(session, public_id, msg)
    
    except WebSocketDisconnect as e:
        logger.info(f"Session {public_id}: WebSocket disconnected (code: {e.code})")
    except Exception as e:
        logger.exception(f"Session {public_id}: WebSocket error: {e}")
    finally:
        # Remove cliente da sessão
        if session and ws in session.websocket_clients:
            logger.info(f"Session {public_id}: Removing WebSocket from session")
            session.remove_websocket(ws)
            logger.info(f"Session {public_id}: WebSocket removed, {len(session.websocket_clients)} clients remaining")


